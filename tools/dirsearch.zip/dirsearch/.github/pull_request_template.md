Description
---------------

Why this PR? What will it do?

If this PR will fix an issue, please address it:
Fix #{issue}

Don't forget :)
---------------

 * Add your name to `CONTRIBUTERS.md`
 * If this is a new feature, then please add some additional information about it to `CHANGELOG.md`


Thank you very much for helping dirsearch become a better tool!!! :heart:
