from common.module import Module


class Query(Module):
    """
    Query base class
    """
    def __init__(self):
        Module.__init__(self)
