from common.module import Module


class Crawl(Module):
    """
    Crawl base class
    """

    def __init__(self):
        Module.__init__(self)
